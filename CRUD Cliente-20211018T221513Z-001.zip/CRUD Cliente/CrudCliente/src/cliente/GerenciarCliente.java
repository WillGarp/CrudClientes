package cliente;

import java.util.Collection;
import java.util.HashMap;

public class GerenciarCliente {

	private int ultimoId;
	private HashMap<Integer, Cliente> clientesBD;
	
	public GerenciarCliente() {
		ultimoId = 0;
		clientesBD = new HashMap<>();
	}
	
	public void create(Cliente cliente)
	{
		cliente.setId(++ultimoId);
		clientesBD.put(ultimoId, cliente);
	}
	
	public Collection<Cliente> listar()
	{
		return clientesBD.values();
	}
	
	public void remover(int id)
	{
		clientesBD.remove(id);
	}
	
	public void update(Cliente cliente)
	{
		this.remover(cliente.getId());
		clientesBD.put(cliente.getId(), cliente);
	}
	
	
	
	
	
	
	
	
	
}
