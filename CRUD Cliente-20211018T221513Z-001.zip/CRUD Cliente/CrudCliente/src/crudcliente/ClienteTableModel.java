/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crudcliente;

import cliente.Cliente;
import cliente.GerenciarCliente;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author IFPR
 */
public class ClienteTableModel extends 
        AbstractTableModel {
   
    private GerenciarCliente gerCliente;
    private String[] nomesColunas;
    private Object[][] dadosTabela;
    private Collection<Cliente> clientes;
    
    public ClienteTableModel(GerenciarCliente gerCliente){
        this.gerCliente = gerCliente;
        nomesColunas = new String[]{"Nome",
            "Data Nascimento",
            "CPF",
            "E-mail"};
        popularMatriz();
    }
    public void atualizarTabela(){
        popularMatriz();
        fireTableDataChanged();
    
    }
    public void popularMatriz(){
     clientes = gerCliente.listar();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyy");
     dadosTabela = new Object[clientes.size()][nomesColunas.length + 1];
     int i = 0;
     for(Cliente cliente : clientes){
         dadosTabela[i][0] = cliente.getNome();
         String dt = sdf.format(cliente.getDataNascimento());
         dadosTabela[i][1] = dt;
         dadosTabela[i][2] = cliente.getCpf();
         dadosTabela[i][3] = cliente.getEmail();
         dadosTabela[i][4] = cliente;
         i++;
     }
     
    }
     
    
    @Override
    public int getRowCount() {
       return clientes.size();
    }
    

    @Override
    public int getColumnCount() {
        return nomesColunas.length;
    }
    

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return dadosTabela[rowIndex][columnIndex];
    }

    
    @Override
    public String getColumnName(int column) {
        return nomesColunas[column];
    }
                    
    
    
}
